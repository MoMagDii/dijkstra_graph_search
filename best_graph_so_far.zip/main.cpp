//=======================================================================
// Copyright 2001 Jeremy G. Siek, Andrew Lumsdaine, Lie-Quan Lee, 
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//=======================================================================
#include <boost/config.hpp>
#include <iostream>
#include <fstream>

#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>

#include "boost/graph/graphviz.hpp"

using namespace boost;

int
main(int, char *[])
{

  typedef adjacency_list < listS, vecS, undirectedS,
    no_property, property < edge_weight_t, double > > graph_t;
  typedef graph_traits < graph_t >::vertex_descriptor vertex_descriptor;
  typedef graph_traits < graph_t >::edge_descriptor edge_descriptor;
  typedef std::pair<int, int> Edge;

  const int num_nodes = 28;
  enum nodes {A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, N1, N2};
  char name[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#$";
  // 45 undirected edges
  Edge edge_array[] = {
      Edge(A, D),
      Edge(B, C),
      Edge(C, E),
      Edge(D, F),
      Edge(E, F), Edge(E, G), Edge(E, H),
      Edge(F, H), Edge(F, J),
      Edge(G, I), Edge(G, N), Edge(G, H),
      Edge(H, I), Edge(H, J), Edge(H, K),
      Edge(I, K), Edge(I, M),
      Edge(J, K), Edge(J, R),
      Edge(K, L),
      Edge(L, M), Edge(L, Q),
      Edge(M, O),
      Edge(N, O), Edge(N, T),
      Edge(O, P),
      Edge(P, Q), Edge(P, S),
      Edge(Q, R),
      Edge(R, W),
      Edge(S, T), Edge(S, Y),
      Edge(T, U),
      Edge(U, V), Edge(U, X), Edge(U, Y),
      Edge(V, X), Edge(V, N1),
      Edge(W, Z),
      Edge(X, Y), Edge(X, Z), Edge(X, N1), Edge(X, N2),
      Edge(Y, Z),
      Edge(Z, N2),
  };
  double weights[] = {
      30.0,
      30.0,
      2.52422,
      2.52422,
      9.375, 2.5242, 5.3125,
      5.3125, 6.832,
      2.12132, 12.3526, 5.0,
      3.80789, 3.8772, 5.7547,
      7.77867, 8.8,
      0.447833, 13.8617,
      0.382326,
      8.96437, 10.8,
      0.440607,
      0.60631, 10.258,
      4.98565,
      4.34916, 4.81845,
      0.696285,
      9.50461,
      3.32539, 6.87385,
      3.76475,
      2.23911, 2.57359, 6.89565,
      2.0, 30.0,
      3.91312,
      5.11553, 8.73212, 30.06, 31.04,
      4.50591,
      26.5
  };
  int num_arcs = sizeof(edge_array) / sizeof(Edge);

  graph_t g(edge_array, edge_array + num_arcs, weights, num_nodes);
  property_map<graph_t, edge_weight_t>::type weightmap = get(edge_weight, g);
  std::vector<vertex_descriptor> p(num_vertices(g));
  std::vector<double> d(num_vertices(g));
  vertex_descriptor s = vertex(A, g);

  dijkstra_shortest_paths(g, s, predecessor_map(&p[0]).distance_map(&d[0]));

  std::cout << "distances and parents:" << std::endl;
  graph_traits < graph_t >::vertex_iterator vi, vend;
  for (tie(vi, vend) = vertices(g); vi != vend; ++vi) {
    std::cout << "distance(" << name[*vi] << ") = " << d[*vi] << ", ";
    std::cout << "parent(" << name[*vi] << ") = " << name[p[*vi]] << std::
      endl;
  }
  std::cout << std::endl;

  std::ofstream dot_file("g.svg");

  dot_file << "digraph D {\n"
    << "  rankdir=LR\n"
    << "  size=\"4,3\"\n"
    << "  ratio=\"fill\"\n"
    << "  edge[style=\"bold\"]\n" << "  node[shape=\"circle\"]\n";

  graph_traits < graph_t >::edge_iterator ei, ei_end;
  for (tie(ei, ei_end) = edges(g); ei != ei_end; ++ei) {
    graph_traits < graph_t >::edge_descriptor e = *ei;
    graph_traits < graph_t >::vertex_descriptor
      u = source(e, g), v = target(e, g);
    dot_file << name[u] << " -> " << name[v]
      << "[label=\"" << get(weightmap, e) << "\"";
    if (p[v] == u)
      dot_file << ", color=\"black\"";
    else
      dot_file << ", color=\"grey\"";
    dot_file << "]";
  }
  dot_file << "}";
   write_graphviz(dot_file, g);
    write_graphviz (std::cout, g, make_label_writer(name));
  return EXIT_SUCCESS;
}

